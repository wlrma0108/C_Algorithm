//2020253091_��ȣ��
#include<stdio.h>
#define _CRT_SECURE_NO_WARNINGS 



int main(void) {
	int university_num = 0;
	int university_favnum =0;

	scanf_s("%d %d", &university_num, &university_favnum,sizeof(university_num),sizeof(university_favnum));


	printf("%d\n", university_num);
	printf("%d", university_favnum);

}