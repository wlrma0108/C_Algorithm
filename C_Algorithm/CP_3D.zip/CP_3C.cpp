//2020253091_��ȣ��

#include<stdio.h>

int main(void) {

	int num1, num2;
	scanf_s("%d %d", &num1, &num2, sizeof(num1), sizeof(num2));
	printf("%d", num1 * num2);

}