//2020253091_��ȣ��
#include<stdio.h>


int main(void) {

	int C, F;
	scanf_s("%d", &F, sizeof(F));
	C = (F - 32) * 5 / 9;

	
	printf("%d \n", C);
	


}