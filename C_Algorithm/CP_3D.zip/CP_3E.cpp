//2020253091_��ȣ��
#include<stdio.h>


int main(void) {

	int num1, num2;
	int a, b, c, d = 0;
	scanf_s("%d %d ", &num1, &num2, sizeof(num1),sizeof(num2));
	

	a = num1 + num2;
	b = num1 - num2;
	c = num1 / num2;
	d = num1 * num2;
	printf("%d \n", a);
	printf("%d \n", b);
	printf("%d \n", c);
	printf("%d \n", d);


}