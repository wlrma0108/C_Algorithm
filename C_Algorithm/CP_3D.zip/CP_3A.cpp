//2020253091_��ȣ��

#include<stdio.h>


int main(void) {
	int university_num = 0;
	scanf_s("%d", &university_num,sizeof(university_num));
	printf("%d", university_num);


}